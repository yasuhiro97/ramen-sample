"""Algorithms implemented in Shapely."""
